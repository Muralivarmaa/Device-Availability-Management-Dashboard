from flask import Flask, render_template_string, request, redirect, url_for
import sqlite3, os, sys, traceback
from datetime import datetime

DB_PATH = "devices.db"
app = Flask(__name__)

# Auto-refresh interval (ms)
REFRESH_MS = 30000  # 30 seconds

TEMPLATE = """
<!doctype html>
<html>
<head>
  <title>Device Availability Dashboard</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <style>
    * { box-sizing: border-box; }
    body {
      margin: 0;
      font-family: system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      font-weight: 700;
      background: linear-gradient(135deg,#4285F4 0%,#EA4335 25%,#FBBC05 50%,#34A853 75%,#4285F4 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 16px;
    }
    .container {
      width: 100%;
      max-width: 1000px;
      background: rgba(255, 255, 255, 0.96);
      border-radius: 18px;
      padding: 18px 22px 20px;
      box-shadow: 0 18px 40px rgba(0,0,0,0.35);
      backdrop-filter: blur(8px);
    }
    .header { display:flex; justify-content:space-between; align-items:baseline; gap:8px; margin-bottom:10px; }
    h2 { margin:0; font-size:24px; letter-spacing:0.03em; color:#111827; }
    .subtitle { font-size:12px; color:#4b5563; font-weight:700; }

    .table-wrapper { max-height:65vh; overflow-y:auto; padding-right:8px; }
    table { width:100%; border-collapse:collapse; margin-top:8px; font-size:14px; }
    th, td { padding:9px 10px; text-align:left; font-weight:700; }
    thead th { background:#111827; color:#f9fafb; border-bottom:2px solid #111827; position:sticky; top:0; z-index:1; }

    .status-available { background:#d1fae5; }
    .status-inuse, .status-maintenance { background:#fee2e2; }
    tbody tr:hover { filter: brightness(0.96); }

    .tag { display:inline-block; padding:2px 8px; border-radius:999px; font-size:11px; text-transform:uppercase; letter-spacing:.05em; }
    .status-available .tag { background:#22c55e; color:#052e16; }
    .status-inuse .tag { background:#ef4444; color:#450a0a; }

    .btn { padding:5px 9px; border-radius:999px; border:none; cursor:pointer; font-size:11px; font-weight:700; text-transform:uppercase; transition:0.15s; }
    .btn-lock { background:#2563eb; color:#fff; }
    .btn-unlock { background:#16a34a; color:#fff; }
    .btn:hover { transform: translateY(-1px); opacity:.95; }
    .btn:active { transform: translateY(0); opacity:.9; }

    form { display:inline-flex; flex-wrap:wrap; gap:4px; align-items:center; }
    input[type="text"], input[type="datetime-local"] { border-radius:999px; border:1px solid #d1d5db; padding:4px 8px; font-size:11px; max-width:150px; font-weight:700; }
    input:focus { outline:none; border-color:#2563eb; box-shadow:0 0 0 1px rgba(37,99,235,.4); }

    /* Modal styles */
    .modal-backdrop { position: fixed; inset: 0; background: rgba(0,0,0,0.45); display: none; align-items: center; justify-content: center; z-index: 9999; }
    .modal { background: #fff; border-radius:12px; padding:18px; width:360px; max-width: calc(100% - 32px); box-shadow:0 12px 30px rgba(0,0,0,0.35); text-align:center; font-weight:700; }
    .modal h3 { margin:0 0 8px 0; font-size:16px; color:#111827; }
    .modal p { margin:0 0 16px 0; font-size:14px; color:#4b5563; font-weight:700; }
    .modal .actions { display:flex; gap:10px; justify-content:center; }
    .modal .actions button { padding:8px 16px; border-radius:999px; border:none; cursor:pointer; font-weight:700; text-transform:uppercase; }
    .modal .actions .btn-yes { background:#16a34a; color:#fff; }
    .modal .actions .btn-no { background:#ef4444; color:#fff; }

    @media (max-width: 768px) {
      .container { padding:14px; }
      table { font-size:12px; }
      th, td { padding:7px 6px; }
      form { flex-direction:column; width:100%; }
      .btn { width:100%; }
      input { width:100%; max-width:none; }
      .modal { width:92%; }
    }
  </style>

  <script>
    // Auto-refresh control (start/stop)
    let refreshInterval = null;
    function startAutoRefresh() {
      if (refreshInterval) return;
      refreshInterval = setInterval(() => { window.location.reload(); }, {{ refresh_ms }});
    }
    function stopAutoRefresh() {
      if (!refreshInterval) return;
      clearInterval(refreshInterval);
      refreshInterval = null;
    }

    // Check for expired ETAs and return the first row that expired (or null)
    function findFirstExpiredRow() {
      const now = new Date();
      // rows with data attributes set on the <tr>
      const rows = document.querySelectorAll('tr[data-eta][data-status="In Use"]');
      for (const r of rows) {
        const eta = r.getAttribute('data-eta');
        if (!eta) continue;
        // parse ETA (ISO or datetime-local style) as local time
        const t = new Date(eta);
        if (isNaN(t.getTime())) continue;
        if (now >= t) return r;
      }
      return null;
    }

    // wait for DOM ready
    document.addEventListener('DOMContentLoaded', function () {
      startAutoRefresh();

      // modal wiring (elements present after DOM ready)
      const modalBackdrop = document.getElementById('confirmModal');
      const modalTitle = document.getElementById('modalTitle');
      const modalMessage = document.getElementById('modalMessage');
      const btnYes = document.getElementById('modalYes');
      const btnNo = document.getElementById('modalNo');

      let pendingForm = null;
      let pendingRow = null;

      function showModalForRow(row) {
        if (!row) return;
        // locate the unlock form inside this row
        const form = row.querySelector('form.unlock-form');
        pendingForm = form;
        pendingRow = row;
        const deviceId = row.getAttribute('data-id') || '?';
        const user = row.getAttribute('data-user') || '-';
        modalTitle.textContent = 'ETA Passed — Confirm Unlock';
        modalMessage.textContent = `Device ${deviceId} used by ${user} has reached its ETA. Do you want to unlock it now?`;
        modalBackdrop.style.display = 'flex';
        modalBackdrop.setAttribute('aria-hidden', 'false');
        btnNo.focus();
        stopAutoRefresh();
      }

      function closeModal() {
        modalBackdrop.style.display = 'none';
        modalBackdrop.setAttribute('aria-hidden', 'true');
        pendingForm = null;
        pendingRow = null;
        startAutoRefresh();
      }

      // If on load an ETA has already passed, show modal immediately
      const expired = findFirstExpiredRow();
      if (expired) showModalForRow(expired);

      // On each future reload the page will re-run this script and show modal again if still expired.

      // Intercept unlock form submit to show modal when user manually clicks Unlock
      document.addEventListener('submit', function (ev) {
        const form = ev.target;
        if (form.classList && form.classList.contains('unlock-form')) {
          // If user clicked Unlock manually we want to show confirmation (same modal)
          ev.preventDefault();
          const row = form.closest('tr');
          showModalForRow(row);
        }
      });

      // Modal buttons
      btnNo.addEventListener('click', function () {
        closeModal();
      });

      btnYes.addEventListener('click', function () {
        if (pendingForm) {
          // submit the stored form programmatically
          pendingForm.submit();
          // after submit the server will redirect back and page will refresh
        } else {
          closeModal();
        }
      });

      // clicking outside modal closes (acts like No)
      modalBackdrop.addEventListener('click', function (e) {
        if (e.target === modalBackdrop) closeModal();
      });

      // keyboard support (Esc = No, Enter = Yes)
      document.addEventListener('keydown', function (e) {
        if (modalBackdrop.style.display !== 'flex') return;
        if (e.key === 'Escape') { e.preventDefault(); closeModal(); }
        else if (e.key === 'Enter') { e.preventDefault(); btnYes.click(); }
      });
    });
  </script>

</head>
<body>
  <div class="container">
    <div class="header">
      <h2>Device Availability</h2>
      <div class="subtitle">Green = Available, Red = In Use</div>
    </div>

    <div class="table-wrapper">
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Device Name</th>
            <th>Status</th>
            <th>Current User</th>
            <th>ETA</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {% for d in devices %}
          <!-- render ETA as-is in data-eta so JS can parse it -->
          <tr data-id="{{ d['id'] }}" data-status="{{ d['status'] }}" data-user="{{ d['current_user'] or '' }}" data-eta="{{ d['eta'] or '' }}" class="status-{{ d['status']|lower|replace(' ', '') }}">
            <td>{{ d['id'] }}</td>
            <td>{{ d['name'] }}</td>
            <td><span class="tag">{{ d['status'] }}</span></td>
            <td>{{ d['current_user'] or '-' }}</td>
            <td>{{ d['eta'] or '-' }}</td>
            <td>
              {% if d['status'] == 'Available' %}
              <form method="post" action="{{ url_for('lock_device', device_id=d['id']) }}">
                <input type="text" name="user" placeholder="Your name" required>
                <input type="datetime-local" name="eta" required>
                <button class="btn btn-lock">Lock</button>
              </form>
              {% else %}
              <!-- unlock form; class unlock-form used by JS -->
              <form class="unlock-form" method="post" action="{{ url_for('unlock_device', device_id=d['id']) }}">
                <button type="submit" class="btn btn-unlock">Unlock</button>
              </form>
              {% endif %}
            </td>
          </tr>
          {% endfor %}
        </tbody>
      </table>
    </div>
  </div>

  <!-- Confirmation modal -->
  <div id="confirmModal" class="modal-backdrop" aria-hidden="true" role="dialog" aria-modal="true">
    <div class="modal" role="document">
      <h3 id="modalTitle">Confirm Unlock</h3>
      <p id="modalMessage">Are you sure you want to unlock?</p>
      <div class="actions">
        <button id="modalYes" class="btn-yes">Yes</button>
        <button id="modalNo" class="btn-no">No</button>
      </div>
    </div>
  </div>

</body>
</html>
"""

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    try:
        create = not os.path.exists(DB_PATH)
        conn = get_db()
        if create:
            print("Creating database:", DB_PATH)
            conn.execute("""
            CREATE TABLE devices (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'Available',
                current_user TEXT,
                eta TEXT
            )
            """)
            for i in range(1, 16):
                conn.execute(
                    "INSERT INTO devices (name, status) VALUES (?, 'Available')",
                    (f"Device {i}",)
                )
            conn.commit()
        conn.close()
    except Exception as e:
        print("Error initializing DB:", e)
        traceback.print_exc()
        sys.exit(1)

@app.route("/")
def index():
    conn = get_db()
    cur = conn.execute("SELECT id, name, status, current_user, eta FROM devices ORDER BY id")
    devices = [dict(row) for row in cur.fetchall()]
    conn.close()
    # pass refresh_ms for JS interval
    return render_template_string(TEMPLATE, devices=devices, refresh_ms=REFRESH_MS)

@app.route("/lock/<int:device_id>", methods=["POST"])
def lock_device(device_id):
    user = request.form.get("user", "").strip()
    eta = request.form.get("eta", "").strip()
    if not user or not eta:
        return redirect(url_for("index"))
    conn = get_db()
    conn.execute(
        "UPDATE devices SET status='In Use', current_user=?, eta=? WHERE id=?",
        (user, eta, device_id),
    )
    conn.commit()
    conn.close()
    return redirect(url_for("index"))

@app.route("/unlock/<int:device_id>", methods=["POST"])
def unlock_device(device_id):
    conn = get_db()
    conn.execute(
        "UPDATE devices SET status='Available', current_user=NULL, eta=NULL WHERE id=?",
        (device_id,),
    )
    conn.commit()
    conn.close()
    return redirect(url_for("index"))

if __name__ == "__main__":
    print("Starting Device Dashboard app...")
    init_db()
    print(f"Running Flask on http://127.0.0.1:5000  (auto-refresh every {REFRESH_MS//1000}s)")
    app.run(host="0.0.0.0", port=5000, debug=True)
